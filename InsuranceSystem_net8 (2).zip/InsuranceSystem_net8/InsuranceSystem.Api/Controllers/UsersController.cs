using Microsoft.AspNetCore.Mvc;
using InsuranceSystem.Core.Data;
using InsuranceSystem.Core.Models;

namespace InsuranceSystem.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private readonly AppDbContext _db;

    public UsersController(AppDbContext db, IWebHostEnvironment env)
    {
        _db = db;
        _db.LoadFromJsonFiles(env.ContentRootPath); // ✅ Ensure paths are initialized
    }

    [HttpGet]
    public IActionResult GetAll() => Ok(_db.Users.ToList());

    [HttpPost("register")]
    public IActionResult Register(User user)
    {
        if (_db.Users.Any(u => u.Email == user.Email))
            return BadRequest("Email already exists");

        user.Id = (_db.Users.Any() ? _db.Users.Max(u => u.Id) : 0) + 1;
        _db.Users.Add(user);
        _db.SaveChanges();
        return Ok(user);
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] User login)
    {
        var user = _db.Users.FirstOrDefault(u => u.Email == login.Email && u.Password == login.Password);
        if (user == null) return Unauthorized("Invalid credentials");
        return Ok(user);
    }
}
