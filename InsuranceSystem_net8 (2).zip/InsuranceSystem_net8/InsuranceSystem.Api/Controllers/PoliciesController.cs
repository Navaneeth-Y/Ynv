using Microsoft.AspNetCore.Mvc;
using InsuranceSystem.Core.Data;
using InsuranceSystem.Core.Models;

namespace InsuranceSystem.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PoliciesController : ControllerBase
{
    private readonly AppDbContext _db;

    public PoliciesController(AppDbContext db, IWebHostEnvironment env)
    {
        _db = db;
        _db.LoadFromJsonFiles(env.ContentRootPath); // ✅ Initialize file paths
    }

    [HttpGet]
    public IActionResult GetAll() => Ok(_db.Policies.ToList());

    [HttpGet("user/{username}")]
    public IActionResult GetByUser(string username) => Ok(_db.Policies.Where(p => p.CreatedBy == username).ToList());

    [HttpGet("{id:int}")]
    public IActionResult Get(int id)
    {
        var p = _db.Policies.FirstOrDefault(x => x.Id == id);
        return p == null ? NotFound() : Ok(p);
    }

    [HttpPost]
    public IActionResult Create([FromBody]Policy policy)
    {
        policy.Id = (_db.Policies.Any() ? _db.Policies.Max(x => x.Id) : 0) + 1;
        _db.Policies.Add(policy);
        _db.SaveChanges();
        return Ok(policy);
    }

    [HttpPut("{id:int}")]
    public IActionResult Update(int id, Policy updated)
    {
        var p = _db.Policies.FirstOrDefault(x => x.Id == id);
        if (p == null) return NotFound();

        p.PolicyNumber = updated.PolicyNumber;
        p.Type = updated.Type;
        p.CoverageAmount = updated.CoverageAmount;
        p.Premium = updated.Premium;
        p.StartDate = updated.StartDate;
        p.EndDate = updated.EndDate;
        p.CreatedBy = updated.CreatedBy;

        _db.SaveChanges();
        return Ok(p);
    }

    [HttpDelete("{id:int}")]
    public IActionResult Delete(int id)
    {
        var p = _db.Policies.FirstOrDefault(x => x.Id == id);
        if (p == null) return NotFound();
        _db.Policies.Remove(p);
        _db.SaveChanges();
        return NoContent();
    }
}
