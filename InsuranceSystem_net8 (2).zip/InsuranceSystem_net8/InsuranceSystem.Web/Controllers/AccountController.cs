using Microsoft.AspNetCore.Mvc;
using InsuranceSystem.Core.Models;
using System.Net.Http.Json;

namespace InsuranceSystem.Web.Controllers;

public class AccountController : Controller
{
    private readonly IHttpClientFactory _factory;
    public AccountController(IHttpClientFactory factory) => _factory = factory;

    public IActionResult Register() => View();

    [HttpPost]
    public async Task<IActionResult> Register(User user)
    {
        var client = _factory.CreateClient("api");
        var res = await client.PostAsJsonAsync("api/users/register", user);
        if (res.IsSuccessStatusCode) return RedirectToAction("Login");
        ModelState.AddModelError(string.Empty, "Registration failed");
        return View(user);
    }

    public IActionResult Login() => View();

    [HttpPost]
    public async Task<IActionResult> Login(string email, string password)
    {
        var client = _factory.CreateClient("api");
        var loginUser = new User { Email = email, Password = password };
        var res = await client.PostAsJsonAsync("api/users/login", loginUser);
        if (!res.IsSuccessStatusCode) { ViewBag.Error = "Invalid credentials"; return View(); }
        var user = await res.Content.ReadFromJsonAsync<User>();
        if (user == null) { ViewBag.Error = "Login failed"; return View(); }
        HttpContext.Session.SetString("Username", user.Username);
        HttpContext.Session.SetString("Role", user.Role);
        HttpContext.Session.SetString("Email", user.Email);
        return user.Role == "Admin" ? RedirectToAction("AdminDashboard") : RedirectToAction("UserDashboard");
    }

    public IActionResult Logout() { HttpContext.Session.Clear(); return RedirectToAction("Login"); }

    public IActionResult UserDashboard()
    {
        if (HttpContext.Session.GetString("Role") != "User") return RedirectToAction("Login");
        return View();
    }

    public IActionResult AdminDashboard()
    {
        if (HttpContext.Session.GetString("Role") != "Admin") return RedirectToAction("Login");
        return View();
    }
}
