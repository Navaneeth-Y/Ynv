using Microsoft.AspNetCore.Mvc;
using InsuranceSystem.Core.Models;
using System.Net.Http.Json;
using Newtonsoft.Json;

namespace InsuranceSystem.Web.Controllers;

public class PoliciesController : Controller
{
    private readonly IHttpClientFactory _factory;
    public PoliciesController(IHttpClientFactory factory) => _factory = factory;

    public async Task<IActionResult> Index()
    {
        var username = HttpContext.Session.GetString("Username");
        var role = HttpContext.Session.GetString("Role");
        if (string.IsNullOrEmpty(username)) return RedirectToAction("Login", "Account");

        var client = _factory.CreateClient("api");
        if (role == "Admin")
        {
            var res = await client.GetFromJsonAsync<List<Policy>>("api/policies");
            return View(res ?? new List<Policy>());
        }
        else
        {
            var res = await client.GetFromJsonAsync<List<Policy>>($"api/policies/user/{username}");
            return View(res ?? new List<Policy>());
        }
    }

    public IActionResult Create() => View();

    [HttpPost]
public async Task<IActionResult> Create([FromForm] Policy policy)
{
    var username = HttpContext.Session.GetString("Username");
    if (string.IsNullOrEmpty(username)) return RedirectToAction("Login", "Account");

    policy.CreatedBy = username;

    // Debug: Check if model binding worked
    Console.WriteLine(JsonConvert.SerializeObject(policy));

    var client = _factory.CreateClient("api");
    var res = await client.PostAsJsonAsync("api/policies", policy);

    if (res.IsSuccessStatusCode)
        return RedirectToAction("Index");

    ModelState.AddModelError(string.Empty, "Failed to create policy");
    return View(policy);
}


    public async Task<IActionResult> Edit(int id)
    {
        var client = _factory.CreateClient("api");
        var res = await client.GetAsync($"api/policies/{id}");
        if (!res.IsSuccessStatusCode) return NotFound();
        var policy = await res.Content.ReadFromJsonAsync<Policy>();
        return View(policy);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(Policy policy)
    {
        var client = _factory.CreateClient("api");
        var res = await client.PutAsJsonAsync($"api/policies/{policy.Id}", policy);
        if (res.IsSuccessStatusCode) return RedirectToAction("Index");
        ModelState.AddModelError(string.Empty, "Failed to update");
        return View(policy);
    }

    public async Task<IActionResult> Delete(int id)
    {
        var client = _factory.CreateClient("api");
        var res = await client.GetAsync($"api/policies/{id}");
        if (!res.IsSuccessStatusCode) return NotFound();
        var policy = await res.Content.ReadFromJsonAsync<Policy>();
        return View(policy);
    }

    [HttpPost, ActionName("Delete")]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var client = _factory.CreateClient("api");
        await client.DeleteAsync($"api/policies/{id}");
        return RedirectToAction("Index");
    }
}
