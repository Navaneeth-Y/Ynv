# InsuranceSystem (.NET 8)
This solution contains three projects:
- InsuranceSystem.Core (models + AppDbContext)
- InsuranceSystem.Api (runs on http://localhost:5001)
- InsuranceSystem.Web (MVC frontend runs on http://localhost:5002)

How to run:
1. Open two terminals.
2. Run API:
   cd InsuranceSystem.Api
   dotnet restore
   dotnet run --urls http://localhost:5001
3. Run Web:
   cd InsuranceSystem.Web
   dotnet restore
   dotnet run --urls http://localhost:5002
