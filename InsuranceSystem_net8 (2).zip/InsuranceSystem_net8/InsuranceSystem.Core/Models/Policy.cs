using System.ComponentModel.DataAnnotations;

namespace InsuranceSystem.Core.Models;

public class Policy
{
    [Key]
    public int Id { get; set; }
    public string PolicyNumber { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public decimal CoverageAmount { get; set; }
    public decimal Premium { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
}
