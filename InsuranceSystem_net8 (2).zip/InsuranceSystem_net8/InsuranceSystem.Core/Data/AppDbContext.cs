using Microsoft.EntityFrameworkCore;
using InsuranceSystem.Core.Models;
using Newtonsoft.Json;

namespace InsuranceSystem.Core.Data
{
    public class AppDbContext : DbContext
    {
        private string _dataFolder = string.Empty;
        private string _usersFile = string.Empty;
        private string _policiesFile = string.Empty;

        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Policy> Policies { get; set; } = null!;

        public void LoadFromJsonFiles(string contentRootPath)
        {
            _dataFolder = Path.Combine(contentRootPath, "Data");
            _usersFile = Path.Combine(_dataFolder, "users.json");
            _policiesFile = Path.Combine(_dataFolder, "policies.json");

            if (!Directory.Exists(_dataFolder))
                Directory.CreateDirectory(_dataFolder);

            if (File.Exists(_usersFile))
            {
                var json = File.ReadAllText(_usersFile);
                var users = JsonConvert.DeserializeObject<List<User>>(json) ?? new List<User>();
                foreach (var u in users)
                {
                    if (!Users.Any(x => x.Id == u.Id))
                        Users.Add(u);
                }
            }

            if (File.Exists(_policiesFile))
            {
                var json = File.ReadAllText(_policiesFile);
                var policies = JsonConvert.DeserializeObject<List<Policy>>(json) ?? new List<Policy>();
                foreach (var p in policies)
                {
                    if (!Policies.Any(x => x.Id == p.Id))
                        Policies.Add(p);
                }
            }

            base.SaveChanges();
        }

        private void PersistToJson()
        {
            // ✅ Ensure paths are initialized before proceeding
            if (string.IsNullOrWhiteSpace(_dataFolder) ||
                string.IsNullOrWhiteSpace(_usersFile) ||
                string.IsNullOrWhiteSpace(_policiesFile))
            {
                throw new InvalidOperationException("Data file paths are not initialized. Call LoadFromJsonFiles() before saving.");
            }

            if (!Directory.Exists(_dataFolder))
                Directory.CreateDirectory(_dataFolder);

            var users = Users.AsNoTracking().ToList();
            var policies = Policies.AsNoTracking().ToList();

            File.WriteAllText(_usersFile, JsonConvert.SerializeObject(users, Formatting.Indented));
            File.WriteAllText(_policiesFile, JsonConvert.SerializeObject(policies, Formatting.Indented));
        }

        public override int SaveChanges()
        {
            var r = base.SaveChanges();
            PersistToJson();
            return r;
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var r = await base.SaveChangesAsync(cancellationToken);
            PersistToJson();
            return r;
        }
    }
}
