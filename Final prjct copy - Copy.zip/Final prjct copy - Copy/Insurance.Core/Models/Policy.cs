using System;
using System.ComponentModel.DataAnnotations;

namespace InsuranceSystem.Core.Models
{
    public class Policy
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        public Guid UserId { get; set; }

        [Required, StringLength(100)]
        public string PolicyNumber { get; set; } = string.Empty;

        [Required]
        public string Type { get; set; } = string.Empty; // health, vehicle, life

        [Range(0, double.MaxValue)]
        public decimal CoverageAmount { get; set; }

        [Range(0, double.MaxValue)]
        public decimal Premium { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }
    }
}
