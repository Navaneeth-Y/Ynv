using System;
using System.ComponentModel.DataAnnotations;

namespace InsuranceSystem.Core.Models
{
    public class User
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        public string Username { get; set; } = string.Empty;

        [Required]
        public string Password { get; set; } = string.Empty; // plain text as requested

        [Required]
        public string Role { get; set; } = "User"; // User or Admin
    }
}
