using Microsoft.EntityFrameworkCore;
using InsuranceSystem.Core.Models;
using Newtonsoft.Json;

namespace InsuranceSystem.Core.Data
{
    public static class AppDbContextFilePaths
    {
        public static string UsersFile = string.Empty;
        public static string PoliciesFile = string.Empty;
    }

    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Policy> Policies { get; set; } = null!;

        public void LoadFromJsonFiles(string contentRootPath)
        {
            var dataFolder = Path.Combine(contentRootPath, "Data");
            AppDbContextFilePaths.UsersFile = Path.Combine(dataFolder, "users.json");
            AppDbContextFilePaths.PoliciesFile = Path.Combine(dataFolder, "policies.json");

            if (!Directory.Exists(dataFolder))
                Directory.CreateDirectory(dataFolder);

            if (File.Exists(AppDbContextFilePaths.UsersFile))
            {
                var json = File.ReadAllText(AppDbContextFilePaths.UsersFile);
                var users = JsonConvert.DeserializeObject<List<User>>(json) ?? new List<User>();
                foreach (var u in users)
                {
                    if (!Users.Any(x => x.Id == u.Id))
                        Users.Add(u);
                }
            }

            if (File.Exists(AppDbContextFilePaths.PoliciesFile))
            {
                var json = File.ReadAllText(AppDbContextFilePaths.PoliciesFile);
                var policies = JsonConvert.DeserializeObject<List<Policy>>(json) ?? new List<Policy>();
                foreach (var p in policies)
                {
                    if (!Policies.Any(x => x.Id == p.Id))
                        Policies.Add(p);
                }
            }

            base.SaveChanges();
        }

        private void PersistToJson()
        {
            if (string.IsNullOrWhiteSpace(AppDbContextFilePaths.UsersFile) ||
                string.IsNullOrWhiteSpace(AppDbContextFilePaths.PoliciesFile))
            {
                throw new InvalidOperationException("Data file paths are not initialized. Call LoadFromJsonFiles() before saving.");
            }

            var users = Users.AsNoTracking().ToList();
            var policies = Policies.AsNoTracking().ToList();

            File.WriteAllText(AppDbContextFilePaths.UsersFile, JsonConvert.SerializeObject(users, Formatting.Indented));
            File.WriteAllText(AppDbContextFilePaths.PoliciesFile, JsonConvert.SerializeObject(policies, Formatting.Indented));
        }

        public override int SaveChanges()
        {
            var result = base.SaveChanges();
            PersistToJson();
            return result;
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var result = await base.SaveChangesAsync(cancellationToken);
            PersistToJson();
            return result;
        }
    }
}
