using InsuranceSystem.Core.Data;
using InsuranceSystem.Core.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace InsuranceSystem.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly IConfiguration _config;

        public AuthController(AppDbContext db, IConfiguration config)
        {
            _db = db;
            _config = config;
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody] User newUser)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);

                if (_db.Users.Any(u => u.Username == newUser.Username))
                    return BadRequest(new { message = "Username already exists" });

                if (string.IsNullOrWhiteSpace(newUser.Role))
                    newUser.Role = "User";

                newUser.Id = Guid.NewGuid();
                _db.Users.Add(newUser);
                _db.SaveChanges();
                return Ok(new { message = "Registered" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] User loginUser)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);

                var user = _db.Users.FirstOrDefault(u => u.Username == loginUser.Username && u.Password == loginUser.Password);
                if (user == null) return Unauthorized(new { message = "Invalid credentials" });

                var token = GenerateJwtToken(user);
                return Ok(new { token, user.Username, user.Role, user.Id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        private string GenerateJwtToken(User user)
        {
            var jwt = _config.GetSection("Jwt");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var token = new JwtSecurityToken(
                issuer: jwt["Issuer"],
                audience: jwt["Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(double.Parse(jwt["ExpireMinutes"]!)),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
