using InsuranceSystem.Core.Data;
using InsuranceSystem.Core.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace InsuranceSystem.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PolicyController : ControllerBase
    {
        private readonly AppDbContext _db;

        public PolicyController(AppDbContext db)
        {
            _db = db;
        }

        private Guid GetUserId()
        {
            var id = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return id == null ? Guid.Empty : Guid.Parse(id);
        }

        private string GetRole()
        {
            return User.FindFirst(ClaimTypes.Role)?.Value ?? "User";
        }

        [HttpGet("mine")]
        public IActionResult GetMyPolicies()
        {
            try
            {
                var userId = GetUserId();
                var list = _db.Policies.Where(p => p.UserId == userId).ToList();
                return Ok(list);
            }
            catch (Exception ex) { return StatusCode(500, new { error = ex.Message }); }
        }

        [HttpGet("all")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetAll()
        {
            try
            {
                var list = _db.Policies.ToList();
                return Ok(list);
            }
            catch (Exception ex) { return StatusCode(500, new { error = ex.Message }); }
        }

        [HttpGet("{id}")]
        public IActionResult Get(Guid id)
        {
            try
            {
                var policy = _db.Policies.FirstOrDefault(p => p.Id == id);
                if (policy == null) return NotFound();
                var role = GetRole();
                var uid = GetUserId();
                if (role != "Admin" && policy.UserId != uid) return Forbid();
                return Ok(policy);
            }
            catch (Exception ex) { return StatusCode(500, new { error = ex.Message }); }
        }

        [HttpPost]
public IActionResult Create([FromBody] Policy policy)
{
    try
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        policy.Id = Guid.NewGuid();
        policy.UserId = GetUserId();
        _db.Policies.Add(policy);
        _db.SaveChanges();
        return Ok(policy);
    }
    catch (Exception ex) { return StatusCode(500, new { error = ex.Message }); }
}


        [HttpPut("{id}")]
        public IActionResult Update(Guid id, [FromBody] Policy updated)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);
                var policy = _db.Policies.FirstOrDefault(p => p.Id == id);
                if (policy == null) return NotFound();
                var role = GetRole();
                var uid = GetUserId();
                if (role != "Admin" && policy.UserId != uid) return Forbid();

                policy.PolicyNumber = updated.PolicyNumber;
                policy.Type = updated.Type;
                policy.CoverageAmount = updated.CoverageAmount;
                policy.Premium = updated.Premium;
                policy.StartDate = updated.StartDate;
                policy.EndDate = updated.EndDate;

                _db.SaveChanges();
                return Ok(policy);
            }
            catch (Exception ex) { return StatusCode(500, new { error = ex.Message }); }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            try
            {
                var policy = _db.Policies.FirstOrDefault(p => p.Id == id);
                if (policy == null) return NotFound();
                var role = GetRole();
                var uid = GetUserId();
                if (role != "Admin" && policy.UserId != uid) return Forbid();

                _db.Policies.Remove(policy);
                _db.SaveChanges();
                return Ok(new { message = "Deleted" });
            }
            catch (Exception ex) { return StatusCode(500, new { error = ex.Message }); }
        }
    }
}
