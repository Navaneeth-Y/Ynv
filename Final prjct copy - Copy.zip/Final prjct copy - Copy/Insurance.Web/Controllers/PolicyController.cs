using Microsoft.AspNetCore.Mvc;
using InsuranceSystem.Core.Models;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace InsuranceSystem.Web.Controllers
{
    public class PolicyController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public PolicyController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        private HttpClient Client()
        {
            var c = _factory.CreateClient("api");
            var token = HttpContext.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
                c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return c;
        }

        public async Task<IActionResult> MyPolicies()
        {
            try
            {
                var client = Client();
                var resp = await client.GetAsync("api/policy/mine");
                if (!resp.IsSuccessStatusCode) return RedirectToAction("Login", "Auth");
                var json = await resp.Content.ReadAsStringAsync();
                var list = JsonConvert.DeserializeObject<List<Policy>>(json) ?? new List<Policy>();
                return View(list);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<Policy>());
            }
        }

        public async Task<IActionResult> AllPolicies()
        {
            try
            {
                var role = HttpContext.Session.GetString("Role");
                if (role != "Admin") return Forbid();
                var client = Client();
                var resp = await client.GetAsync("api/policy/all");
                if (!resp.IsSuccessStatusCode) return Forbid();
                var json = await resp.Content.ReadAsStringAsync();
                var list = JsonConvert.DeserializeObject<List<Policy>>(json) ?? new List<Policy>();
                return View(list);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<Policy>());
            }
        }

        public IActionResult Create() => View(new Policy { StartDate = DateTime.UtcNow.Date, EndDate = DateTime.UtcNow.Date.AddYears(1) });

        [HttpPost]
public async Task<IActionResult> Create(Policy model)
{
    try
    {
        if (!ModelState.IsValid)
        {
            ModelState.AddModelError("", "Please correct the errors and try again.");
            return View(model);
        }

        var client = Client();
        var resp = await client.PostAsJsonAsync("api/policy", model);

        if (resp.IsSuccessStatusCode)
        {
            TempData["Success"] = "Policy created successfully!";
            return RedirectToAction("MyPolicies");
        }

        var err = await resp.Content.ReadAsStringAsync();
        ModelState.AddModelError("", $"API Error: {err}");
        return View(model);
    }
    catch (Exception ex)
    {
        ModelState.AddModelError("", $"Exception: {ex.Message}");
        return View(model);
    }
}


        public async Task<IActionResult> Edit(Guid id)
        {
            try
            {
                var client = Client();
                var resp = await client.GetAsync($"api/policy/{id}");
                if (!resp.IsSuccessStatusCode) return NotFound();
                var json = await resp.Content.ReadAsStringAsync();
                var policy = JsonConvert.DeserializeObject<Policy>(json);
                return View(policy);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return RedirectToAction("MyPolicies");
            }
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Guid id, Policy model)
        {
            try
            {
                if (!ModelState.IsValid) return View(model);
                var client = Client();
                var resp = await client.PutAsJsonAsync($"api/policy/{id}", model);
                if (resp.IsSuccessStatusCode) return RedirectToAction("MyPolicies");
                var err = await resp.Content.ReadAsStringAsync();
                ModelState.AddModelError("", err);
                return View(model);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(model);
            }
        }

        public async Task<IActionResult> Details(Guid id)
        {
            try
            {
                var client = Client();
                var resp = await client.GetAsync($"api/policy/{id}");
                if (!resp.IsSuccessStatusCode) return NotFound();
                var json = await resp.Content.ReadAsStringAsync();
                var policy = JsonConvert.DeserializeObject<Policy>(json);
                return View(policy);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return RedirectToAction("MyPolicies");
            }
        }

        public async Task<IActionResult> Delete(Guid id)
        {
            try
            {
                var client = Client();
                var resp = await client.GetAsync($"api/policy/{id}");
                if (!resp.IsSuccessStatusCode) return NotFound();
                var json = await resp.Content.ReadAsStringAsync();
                var policy = JsonConvert.DeserializeObject<Policy>(json);
                return View(policy);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return RedirectToAction("MyPolicies");
            }
        }

        [HttpPost, ActionName("DeleteConfirmed")]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            try
            {
                var client = Client();
                var resp = await client.DeleteAsync($"api/policy/{id}");
                if (resp.IsSuccessStatusCode) return RedirectToAction("MyPolicies");
                var err = await resp.Content.ReadAsStringAsync();
                ModelState.AddModelError("", err);
                return RedirectToAction("MyPolicies");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return RedirectToAction("MyPolicies");
            }
        }
    }
}
