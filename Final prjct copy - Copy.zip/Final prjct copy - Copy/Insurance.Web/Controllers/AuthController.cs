using Microsoft.AspNetCore.Mvc;
using InsuranceSystem.Core.Models;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace InsuranceSystem.Web.Controllers
{
    public class AuthController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public AuthController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(User model)
        {
            try
            {
                if (!ModelState.IsValid) return View(model);
                var client = _factory.CreateClient("api");
                var resp = await client.PostAsJsonAsync("api/auth/register", model);
                if (resp.IsSuccessStatusCode) return RedirectToAction("Login");
                var err = await resp.Content.ReadAsStringAsync();
                ModelState.AddModelError("", err);
                return View(model);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Login() => View();

      [HttpPost]
public async Task<IActionResult> Login(User model)
{
    try
    {
        if (!ModelState.IsValid)
        {
            Console.WriteLine("ModelState is invalid");

            foreach (var entry in ModelState)
            {
                var key = entry.Key;
                var errors = entry.Value.Errors;
                foreach (var error in errors)
                {
                    Console.WriteLine($"Field: {key}, Error: {error.ErrorMessage}");
                }
            }

            return View(model);
        }

        var client = _factory.CreateClient("api");
        var resp = await client.PostAsJsonAsync("api/auth/login", model);
        var json = await resp.Content.ReadAsStringAsync();

        Console.WriteLine($"API Response Status: {resp.StatusCode}");
        Console.WriteLine($"API Response Body: {json}");

        if (!resp.IsSuccessStatusCode)
        {
            ModelState.AddModelError("", "Invalid username or password");
            return View(model);
        }

        var obj = JsonConvert.DeserializeObject<dynamic>(json);
        string token = obj.token;
        string role = obj.role;         // ✅ fixed
        string username = obj.username; // ✅ fixed

        HttpContext.Session.SetString("JwtToken", token);
        HttpContext.Session.SetString("Role", role);
        HttpContext.Session.SetString("Username", username);

        

        return RedirectToAction("Index", "Home"); // ✅ redirect after login
    }
    catch (Exception ex)
    {
        ModelState.AddModelError("", $"Login failed: {ex.Message}");
        return View(model);
    }
}





        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
